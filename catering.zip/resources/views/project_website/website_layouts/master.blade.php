<!DOCTYPE html>
<html lang="en">
<!-- Mirrored from html.merku.love/rotors/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 22 May 2021 09:13:29 GMT -->
@include('project_website.website_assets.head')
<body data-bg-image="demo_assets/images/backgrounds/bg_00.png">
<div id="thetop"></div>
<div class="backtotop"><a href="#" class="scroll"><i class="far fa-arrow-up"></i></a></div>

@include('project_website.website_assets.topbar')
@yield('content')


@include('project_website.website_assets.footer')
@include('project_website.website_assets.scripts')
</body>
<!-- Mirrored from html.merku.love/rotors/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 22 May 2021 09:14:00 GMT -->
</html>
