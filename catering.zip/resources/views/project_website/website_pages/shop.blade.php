@extends('project_website.website_layouts.master')
@section('content')
    <section class="breadcrumb_section text-center clearfix">
        <div class="page_title_area has_overlay d-flex align-items-center clearfix" style="min-height: 300px;" data-bg-image="{{asset('project_website/assets/images/breadcrumb/bg_08.jpg')}}">
            <div class="overlay"></div>
            <div class="container" data-aos="fade-up" data-aos-delay="100">
                <h1 class="page_title text-white mb-0">Muneeb</h1>
            </div>
        </div>
        <div class="breadcrumb_nav clearfix" data-bg-color="#F2F2F2">
            <div class="container">
                <ul class="ul_li clearfix">
                    <li><a href="">Home</a></li>
                    <li>Shop</li>

                </ul>
            </div>
        </div>
    </section>
    <section>
        <div class="row">
            <div class="col-lg-11  info-section p-5 ml-5" style="background: none !important; ">
                @foreach($get_service as $keys=>$values)
                    <div class="card col-md-5 col-sm-12 shadow-lg p-3 mb-5 bg-white rounded" style="float: left; ">
                        <div class="cart-body" >
                            <div class="col-md-4" style="float: left;" >
                                <img src="{{asset('project_panel/assets/images/service_images/'.$values->ServiceImage->image)}}" alt="">
                            </div>
                            <div class="col-md-8" style="float: left;" >
                                <h5>{{$values->title}}</h5>
                                <p style="color: red;"><a href="">{{$values->User->name}}</a></p>
                                <h6> ${{$values->price}}</h6>
                                <a href="{{route('service_details',$values->id)}}" class="btn btn-primary"><i class="fa fa-eye"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class=" card col-md-1 col-sm-12 " style="float: left; border: none; background: none;"><div class="card-body"></div></div>
                @endforeach

            </div>
        </div>
    </section>
@endsection
