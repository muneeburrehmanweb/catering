<div class="sidebar-menu-wrapper">
    <div class="mobile_sidebar_menu">
        <button type="button" class="close_btn"><i class="fal fa-times"></i></button>

        <div class="menu_list mb_60 clearfix">
            <h3 class="title_text text-white">Menu List</h3>
            <ul class="ul_li_block clearfix">

                <li><a href="gallery.html">About</a></li>
                <li><a href="{{route('faq')}}">FAQ</a></li>
                <li><a href="about.html">Blog</a></li>

            </ul>
        </div>

    </div>
    <div class="overlay"></div>
</div>
