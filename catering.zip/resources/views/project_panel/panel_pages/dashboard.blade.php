@extends('project_panel.panel_layouts.master')
@section('title')
    Dashboard
@endsection
@section('content')

{{--    page title and breadcrumb starts--}}
    @section('page_title')
        Dashboard
    @endsection
    @section('breadcrumb')
        Dashboard
    @endsection
{{--title and brudcrumb ends--}}
@endsection
