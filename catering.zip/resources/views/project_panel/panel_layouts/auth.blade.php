<!DOCTYPE html>
<html lang="en">

@include('project_panel.panel_assets.head')

<body>
    <!-- [ Main Content ] start -->
    @section('content')
    @show
    <!-- [ Main Content ] start -->

    <!-- Required Js -->
    @include('project_panel.panel_assets.scripts')
</body>
</html>