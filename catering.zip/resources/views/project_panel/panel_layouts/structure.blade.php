@extends('project_panel.panel_layouts.master')
@section('title')
    Dashboard
@endsection
@section('content')
@section('page_title')
    Dashboard
@endsection
@section('breadcrumb')
    Dashboard
@endsection


@endsection
