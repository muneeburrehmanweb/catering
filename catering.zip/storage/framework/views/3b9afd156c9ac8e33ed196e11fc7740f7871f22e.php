<!DOCTYPE html>
<html lang="en">


<!-- Mirrored from ableproadmin.com/bootstrap/default/ by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 22 Nov 2021 10:16:15 GMT -->
<?php echo $__env->make('project_panel.panel_assets.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('project_panel.panel_assets.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body class="">
<!-- [ Pre-loader ] start -->
<div class="loader-bg">
    <div class="loader-track">
        <div class="loader-fill"></div>
    </div>
</div>
<!-- [ Pre-loader ] End -->
<!-- [ breadcrumb ] start -->

<?php echo $__env->make('project_panel.panel_assets.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<!-- [ Main Content ] start -->
<?php $__env->startSection('content'); ?>
<?php echo $__env->yieldSection(); ?>
<!-- [ Main Content ] start -->



<!-- Required Js -->
<?php echo $__env->make('project_panel.panel_assets.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="pcoded-main-container">
    <div class="pcoded-content">
        <!-- [ breadcrumb ] start -->
        <div class="page-header">
            <div class="page-block">
                <div class="row align-items-center">
                    <div class="col-md-12">
                        <div class="page-header-title">

                            <h5 class="m-b-10"><?php $__env->startSection('page_title'); ?><?php echo $__env->yieldSection(); ?></h5>
                        </div>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="index-2.html"><i class="feather icon-home"></i></a></li>
                            <li class="breadcrumb-item"><a href=""><?php $__env->startSection('breadcrumb'); ?><?php echo $__env->yieldSection(); ?></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
        <!-- [ breadcrumb ] end -->

</body>


<!-- Mirrored from ableproadmin.com/bootstrap/default/ by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 22 Nov 2021 10:18:13 GMT -->
</html>
<?php /**PATH C:\projects\template_able_pro_laravel_8\resources\views/project_panel/panel_layouts/master.blade.php ENDPATH**/ ?>