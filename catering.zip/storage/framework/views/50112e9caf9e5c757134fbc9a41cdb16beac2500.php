<?php $__env->startSection('content'); ?>
    <section class="breadcrumb_section text-center clearfix">
        <div class="page_title_area has_overlay d-flex align-items-center clearfix" style="min-height: 300px;" data-bg-image="<?php echo e(asset('project_website/assets/images/breadcrumb/bg_08.jpg')); ?>">
            <div class="overlay"></div>
            <div class="container" data-aos="fade-up" data-aos-delay="100">
                <h1 class="page_title text-white mb-0">Muneeb</h1>
            </div>
        </div>
        <div class="breadcrumb_nav clearfix" data-bg-color="#F2F2F2">
            <div class="container">
                <ul class="ul_li clearfix">
                    <li><a href="">Home</a></li>
                    <li>Shop</li>

                </ul>
            </div>
        </div>
    </section>
    <section>
        <div class="row">
            <div class="col-lg-11  info-section p-5 ml-5" style="background: none !important; ">
                <?php $__currentLoopData = $get_service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keys=>$values): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card col-md-5 col-sm-12 shadow-lg p-3 mb-5 bg-white rounded" style="float: left; ">
                        <div class="cart-body" >
                            <div class="col-md-4" style="float: left;" >
                                <img src="<?php echo e(asset('project_panel/assets/images/service_images/'.$values->ServiceImage->image)); ?>" alt="">
                            </div>
                            <div class="col-md-8" style="float: left;" >
                                <h5><?php echo e($values->title); ?></h5>
                                <p style="color: red;"><a href=""><?php echo e($values->User->name); ?></a></p>
                                <h6> $<?php echo e($values->price); ?></h6>
                                <a href="<?php echo e(route('service_details',$values->id)); ?>" class="btn btn-primary"><i class="fa fa-eye"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class=" card col-md-1 col-sm-12 " style="float: left; border: none; background: none;"><div class="card-body"></div></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('project_website.website_layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projects\catering\resources\views/project_website/website_pages/shop.blade.php ENDPATH**/ ?>