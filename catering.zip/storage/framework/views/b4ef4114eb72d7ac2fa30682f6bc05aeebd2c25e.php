<?php $__env->startSection('title'); ?>
    Dashboard
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('page_title'); ?>
    Dashboard
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
    Dashboard
<?php $__env->stopSection(); ?>
<div class="row">
    <!-- customar project  start -->
    <div class="col-xl-12">
        <div class="card">
            <div class="card-body">
                <div class="row align-items-center m-l-0">
                    <div class="col-sm-6">
                        <h5>Category</h5>
                    </div>

                </div>
                <hr>
                <form action="<?php echo e(route('submit_category')); ?>" method="post" class="needs-validation" novalidate >
                    <?php echo csrf_field(); ?>
                    <div class="form-group col-md-8" style="float: left;">

                        <input type="text" class="form-control" name="category_title" id="category_title" placeholder="Enter A Category Title" required>
                        <div class="valid-feedback">
                            Looks good!
                        </div>
                        <div class="invalid-feedback">
                            you can't leave it blank.
                        </div>
                    </div>
                    <div class="form-group col-md-2" style="float: left;">
                    <button type="submit" class="btn btn-primary">Add Category</button>
                    </div>
                </form>
                <div class="table-responsive">
                    <table id="report-table" class="table mb-0">
                        <thead class="thead-light">
                        <tr>
                            <th>title</th>
                            <th>Added Date</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $show_services_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keys=>$values): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="align-middle">

                                    <p class="m-0 d-inline-block align-middle font-16">
                                        <a href="#!" class="text-body"><?php echo e($values->title ?? ''); ?></a>
                                    </p>
                                </td>
                                <td class="align-middle">
                                    <?php echo e($values->created_at ?? ''); ?>

                                </td>

                                <td class="align-middle">
                                    <span class="badge badge-success"><?php echo e($values->status ?? ''); ?></span>
                                </td>

                                <td class="table-action">


                                    <a href="<?php echo e(route('del_category',$values->id)); ?>" class="btn btn-icon btn-outline-danger"><i class="feather icon-trash-2"></i></a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <!-- customar project  end -->
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('project_panel.panel_layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projects\catering\resources\views/project_panel/panel_pages/service_category.blade.php ENDPATH**/ ?>