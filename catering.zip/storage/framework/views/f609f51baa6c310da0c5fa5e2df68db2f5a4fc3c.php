<?php $__env->startSection('title'); ?>
    Add Service
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<?php $__env->startSection('page_title'); ?>
    Add Service
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
    Add Service
<?php $__env->stopSection(); ?>
<?php echo $__env->make('project_panel.panel_assets.status_bars', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="col-sm-12">
    <div class="card">
        <div class="card-header">
            <h5>Add Services</h5>

        </div>
        <div class="card-body">
            <?php if(!$get_service): ?>
                <form action="<?php echo e(route('submit_service')); ?>" method="post" enctype="multipart/form-data" class="needs-validation" novalidate >
            <?php else: ?>
                <form action="<?php echo e(route('update_services',$get_service->id)); ?>" method="post" enctype="multipart/form-data" class="needs-validation" novalidate >
            <?php endif; ?>
                <?php echo csrf_field(); ?>
                <div class="form-row">
                    <div class="form-group col-md-12">
                    <div class="custom-file">
                        <label for="inputEmail4">Service Images</label>
                        <?php if(!$get_service): ?>
                        <input type="file" name="service_image" class="custom-file-input" id="validatedCustomFile"  required>
                        <?php else: ?>
                        <input type="file" name="service_image" class="custom-file-input" id="validatedCustomFile" value="<?php echo e($get_service_image->image ?? ''); ?>">
                        <?php endif; ?>
                        <label class="custom-file-label" for="validatedCustomFile">Choose images...</label>
                        <div class="invalid-feedback">Example invalid custom file feedback</div>
                    </div>
                    </div>
                    <div class="form-group col-md-12">
                        <label for="inputEmail4">Title</label>
                        <input type="text" class="form-control" name="service_title" id="service_title" placeholder="Service Title" value="<?php echo e($get_service->title ?? ''); ?>" required>
                        <div class="valid-feedback">
                            Looks good!
                        </div>
                        <div class="invalid-feedback">
                            you can't leave it blank.
                        </div>
                    </div>
                    <div class="form-group col-md-12">
                        <label for="service_category">Select Category</label>
                        <select class="custom-select" name="service_category" id="service_category" required>
                            <option value="<?php echo e($get_service->category ?? ''); ?>"><?php echo e($get_service->category ?? 'Must Select One'); ?></option>
                            <?php $__currentLoopData = $services_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keys=>$values): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($values->title); ?>"><?php echo e($values->title); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <div class="invalid-feedback">Example invalid custom select feedback</div>
                    </div>
                    <div class="form-group col-md-12">
                        <label for="inputEmail4">Price</label>
                        <input type="text" class="form-control" name="service_price" id="service_price" placeholder="Service Price" value="<?php echo e($get_service->price ?? ''); ?>" required>
                        <div class="valid-feedback">
                            Looks good!
                        </div>
                        <div class="invalid-feedback">
                            you can't leave it blank.
                        </div>
                    </div>
                    <div class="form-group col-md-12">
                        <label for="inputEmail4">Menu Details</label>
                        <textarea name="menu_details" id="main-menu" required><?php echo e($get_service->menu_details ?? ''); ?></textarea>
                        <div class="valid-feedback">
                            Looks good!
                        </div>
                        <div class="invalid-feedback">
                            you can't leave it blank.
                        </div>
                    </div>
                    <div class="form-group col-md-12">
                        <label for="inputEmail4">Add Ons</label>
                        <textarea name="add_ons" id="add-ons" required><?php echo e($get_service->add_ons ?? ''); ?></textarea>
                        <div class="valid-feedback">
                            Looks good!
                        </div>
                        <div class="invalid-feedback">
                            you can't leave it blank.
                        </div>
                    </div>


                </div>
                <?php if($get_service): ?>
                    <button type="submit" class="btn btn-primary">Update Service</button>
                <?php else: ?>
                    <button type="submit" class="btn btn-primary">Add Service</button>
                <?php endif; ?>

            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('project_panel.panel_layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projects\catering\resources\views/project_panel/panel_pages/add_service.blade.php ENDPATH**/ ?>