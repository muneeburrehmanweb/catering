<?php if(session()->has('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert" style="margin: 6px 7px;">
        <strong>Success! </strong> <?php echo e(session()->get('success')); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
    </div>
<?php endif; ?>
<?php if(session()->has('error')): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert" style="margin: 6px 7px;">
        <strong>Error! </strong> <?php echo e(session()->get('error')); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
    </div>
<?php endif; ?>


<?php /**PATH C:\projects\catering\resources\views/project_panel/panel_assets/status_bars.blade.php ENDPATH**/ ?>