<?php $__env->startSection('title'); ?>
    Profile
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('page_title'); ?>
    Profile
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
    Profile
<?php $__env->stopSection(); ?>
<?php echo $__env->make('project_panel.panel_assets.status_bars', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="col-md-4 order-md-1" style="float: left;">
    <div class="card">
        <div class="card-header d-flex align-items-center justify-content-between">
            <h5 class="mb-0">Profile</h5>

        </div>
        <div class="card-body" style="text-align: center;">
            <ul class="list-inline">
                <li class="list-inline-item" >
                    <div class="position-relative d-inline-block " >
                        <img class="img-radius img-fluid wid-100" src="<?php echo e(asset('project_panel/assets/images/user/avatar-5.jpg')); ?>" alt="User image">
                    </div>
                    <h3><?php echo e($get_profile->name); ?></h3>

                </li>

            </ul>
        </div>
    </div>

</div>
<div class="col-md-8 order-md-1" style="float: left;">
    <div class="card">
        <div class="card-header d-flex align-items-center justify-content-between">
            <h5 class="mb-0">Profile</h5>

        </div>
        <div class="card-body">
            <form id="validation-form123" action="<?php echo e(route('update_profile')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <label class="form-label">Name</label>
                            <input type="text" class="form-control" name="name" value="<?php echo e($get_profile->name); ?>" readonly>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <label class="form-label">Email</label>
                            <input type="text" class="form-control" name="email" value="<?php echo e($get_profile->email); ?>" readonly>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <label class="form-label">Contact</label>
                            <input type="text" class="form-control" name="contact" value="<?php echo e($get_profile->Merchant->contact ?? ''); ?>" required>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <label class="form-label">City</label>
                            <input type="text" class="form-control" name="city" value="<?php echo e($get_profile->Merchant->city ?? ''); ?>" required>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <label class="form-label">Country</label>
                            <input type="text" class="form-control" name="country" value="<?php echo e($get_profile->Merchant->country ?? ''); ?>" required>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <label class="form-label">Address</label>
                            <input type="text" class="form-control" name="address" value="<?php echo e($get_profile->Merchant->address ?? ''); ?>" required>
                        </div>
                    </div>
                </div>
                <button type="submit" class="btn  btn-primary">Update</button>
            </form>
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('project_panel.panel_layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projects\catering\resources\views/project_panel/panel_pages/profile.blade.php ENDPATH**/ ?>