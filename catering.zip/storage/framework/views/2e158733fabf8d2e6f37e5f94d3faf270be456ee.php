

<script data-cfasync="false" src="../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script>
<script src="<?php echo e(asset('project_website/assets/js/jquery-3.5.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('project_website/assets/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('project_website/assets/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('project_website/assets/js/aos.js')); ?>"></script>
<script src="<?php echo e(asset('project_website/assets/js/parallaxie.js')); ?>"></script>
<script src="<?php echo e(asset('project_website/assets/js/slick.min.js')); ?>"></script>
<script src="<?php echo e(asset('project_website/assets/js/magnific-popup.min.js')); ?>"></script>
<script src="<?php echo e(asset('project_website/assets/js/nice-select.min.js')); ?>"></script>
<script src="<?php echo e(asset('project_website/assets/js/isotope.pkgd.js')); ?>"></script>
<script src="<?php echo e(asset('project_website/assets/js/imagesloaded.pkgd.min.js')); ?>"></script>
<script src="<?php echo e(asset('project_website/assets/js/masonry.pkgd.min.js')); ?>"></script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDk2HrmqE4sWSei0XdKGbOMOHN3Mm2Bf-M&amp;ver=2.1.6"></script>
<script src="<?php echo e(asset('project_website/assets/js/gmaps.min.js')); ?>"></script>
<script src="<?php echo e(asset('project_website/assets/js/jquery-ui.js')); ?>"></script>
<script src="<?php echo e(asset('project_website/assets/js/waypoint.js')); ?>"></script>
<script src="<?php echo e(asset('project_website/assets/js/counterup.min.js')); ?>"></script>
<script src="<?php echo e(asset('project_website/assets/js/validate.js')); ?>"></script>
<script src="<?php echo e(asset('project_website/assets/js/mCustomScrollbar.js')); ?>"></script>
<script src="<?php echo e(asset('project_website/assets/js/custom.js')); ?>"></script>
<script async src="https://www.googletagmanager.com/gtag/js?id=G-M3VBLFRFMN"></script>
<script>function gtag(){dataLayer.push(arguments)}window.dataLayer=window.dataLayer||[],gtag("js",new Date),gtag("config","G-M3VBLFRFMN")</script>
<?php /**PATH C:\projects\catering\resources\views/project_website/website_assets/scripts.blade.php ENDPATH**/ ?>