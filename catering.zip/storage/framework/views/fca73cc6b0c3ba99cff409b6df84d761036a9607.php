<?php $__env->startSection('title'); ?>
    Pending Orders
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('page_title'); ?>
    Pending Orders
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
    Pending Orders
<?php $__env->stopSection(); ?>


        <!-- [ Main Content ] start -->
        <div class="row">
            <!-- customar project  start -->
            <div class="col-12">
                <?php $__currentLoopData = $my_orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keys=>$values): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card">
                    <div class="card-body">
                        <div class="row align-items-center justify-contact-between">
                            <div class="col">
                                <div class="btn btn-primary">
                                    <?php echo e($values->order_id); ?>

                                </div>
                            </div>
                            <div class="col text-right">
                                <button class="btn btn-outline-primary">
                                    <i class="feather icon-thumbs-up"></i> Fulfill
                                </button>
                            </div>
                        </div>
                        <?php
                            $service=App\Models\Service::Where('id',$values->service_id)->with('ServiceImage')->first();
                        ?>
                        <div class="table-responsive">
                            <table class="table m-0 mt-3">
                                <tr>
                                    <td class="align-middle">
                                        <img src="<?php echo e(asset('project_panel/assets/images/service_images/'.$service->ServiceImage->image)); ?>" alt="contact-img" title="contact-img" class="rounded mr-3" height="80" />
                                        <div class="m-0 d-inline-block align-middle font-16">
                                            <a href="<?php echo e(route('service_details',$values->service_id)); ?>" class="text-body" target="_blank">

                                                <h6 class="d-inline-block"><?php echo e($service->title); ?></h6>
                                            </a>
                                            <br />





                                        </div>
                                    </td>
                                    <td>
                                        <h5>$<?php echo e($service->price); ?></h5>
                                    </td>
                                    <td>
                                        <h5><?php echo e($values->persons); ?> <i class="fa fa-user-circle"  ></i></h5>
                                    </td>
                                    <td class="text-right">
                                        <div class="text-left d-inline-block">
                                            <h6 class="my-0">Event at , <?php echo e($values->date); ?></h6>
                                            <small class="text-muted"><?php echo e($values->information); ?></small>
                                        </div>
                                    </td>
                                </tr>
                            </table>
                        </div>
                        <hr class="mt-0">
                        <div class="row align-items-center justify-contact-between">
                            <div class="col">
                                <span class="text-muted">Ordered On</span>
                                <strong><?php echo e($values->created_at); ?></strong>
                            </div>
                            <div class="col text-right">
                                    <?php
                                    $total_amount=$service->price * $values->persons;
                                    ?>
                                <span class="text-muted">Ordered Amount</span>
                                <strong>$<?php echo e($total_amount); ?></strong>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <!-- customar project  end -->
        </div>
        <!-- [ Main Content ] end -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('project_panel.panel_layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projects\catering\resources\views/project_panel/panel_pages/pending_orders.blade.php ENDPATH**/ ?>