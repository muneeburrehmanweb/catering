<nav class="pcoded-navbar menu-light ">
    <div class="navbar-wrapper  ">
        <div class="navbar-content scroll-div " >

            <div class="">
                <div class="main-menu-header">
                    <img class="img-radius" src="<?php echo e(asset('project_panel/assets/images/user/avatar-2.jpg')); ?>" alt="User-Profile-Image">
                    <div class="user-details">
                        <div id="more-details">UX Designer </div>
                    </div>
                </div>

            </div>

            <ul class="nav pcoded-inner-navbar ">
                <li class="nav-item pcoded-menu-caption">
                    <label>Navigation</label>
                </li>
                <li class="nav-item pcoded-hasmenu">
                    <a href="#!" class="nav-link "><span class="pcoded-micon"><i class="feather icon-home"></i></span><span class="pcoded-mtext">Dashboard</span></a>
                    <ul class="pcoded-submenu">
                        <li><a href="index-2.html">Default</a></li>
                        <li><a href="dashboard-sale.html">Sales</a></li>
                        <li><a href="dashboard-crm.html">CRM</a></li>
                        <li><a href="dashboard-analytics.html">Analytics</a></li>
                        <li><a href="dashboard-project.html">Project</a></li>
                    </ul>
                </li>

            </ul>



        </div>
    </div>
</nav>
<?php /**PATH C:\projects\template_able_pro_laravel_8\resources\views/project_panel/panel_assets/sidebar.blade.php ENDPATH**/ ?>