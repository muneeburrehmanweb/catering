<?php $__env->startSection('content'); ?>

    <style>

        .info-section{
            background: hsla(240, 75%, 66%, 1);

            background: radial-gradient(circle, hsla(240, 75%, 66%, 1) 0%, hsla(246, 100%, 50%, 1) 100%);

            background: -moz-radial-gradient(circle, hsla(240, 75%, 66%, 1) 0%, hsla(246, 100%, 50%, 1) 100%);

            background: -webkit-radial-gradient(circle, hsla(240, 75%, 66%, 1) 0%, hsla(246, 100%, 50%, 1) 100%);

            filter: progid: DXImageTransform.Microsoft.gradient( startColorstr="#6666E9", endColorstr="#1900FF", GradientType=1 );
        }
    </style>
    <main>
<?php echo $__env->make('project_website.website_assets.sidebar_wrap_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <section class="banner_section parallaxie has_overlay text-white d-flex align-items-center clearfix" data-bg-image="<?php echo e(asset('project_website/assets/images/backgrounds/bg_01.jpg')); ?>">
            <div class="overlay"></div>
            <div class="container">

                <div class="advance_search_form mt-0">
                    <div class="section_title text-center mb_30">

                        <h2 class="title_text mb-0 text-white" data-aos="fade-up" data-aos-delay="100"><span>order on demand catering from local restaurants nationwide</span></h2>
                    </div>
                    <form action="<?php echo e(route('services_page')); ?>" method="get">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
                                <div class="form_item" data-aos="fade-up" data-aos-delay="100">

                                    <div class="position-relative"><input id="location_two" type="text" name="service" placeholder="order on demand catering from local restaurants nationwide"> <label for="location_two" class="input_icon"><i class="fas fa-map-marker-alt"></i></label></div>
                                </div>
                            </div>

                            <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                                <div data-aos="fade-up" data-aos-delay="300" class="col text-center"><button type="submit" class="custom_btn bg_default_red btn_width text-uppercase">Search <img src="<?php echo e(asset('project_website/assets/images/icons/icon_01.png')); ?>" alt="icon_not_found"></button></div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </section>
























        <section>
            <div class="row">

                    <div class="col-lg-12 info-section p-4">
                        <div class="card col-md-4 col-sm-12" style="background: none; border: none; float: left; ">
                            <div class="cart-body col-md-10" style="text-align: center;">
                                <h1 style="color: #ffae4c; "><i class="fa fa-crown mt-4" style="font-size: 68px; transform: scale(2, 1);"></i></h1>
                                <h3 style="color: #FFFFFF; font-family: Helvetica Neue, Helvetica, sans-serif !important; ">What is catering King?<strong></strong></h3>
                                <p style="color: #FFFFFF;">we are on online catering marketplace partnering with local business to provide on demand catering to everbody.</p>
                            </div>
                        </div>
                        <div class="card col-md-4 col-sm-12" style="background: none; border: none; float: left;">
                            <div class="cart-body col-md-10" style="text-align: center;">
                                <h1 style="color: #ffae4c; "><img class="mt-4" src="<?php echo e(asset('project_website/assets/images/logo/cutlery.png')); ?>" style="height: 68px; width: 68px;"></h1>
                                <h3 style="color: #FFFFFF; font-family: Helvetica Neue, Helvetica, sans-serif !important; ">Support Small Business<strong></strong></h3>
                                <p style="color: #FFFFFF;">We Partner exclusively with small businesses. Enjoy carefully crafted meals made by local culinary experts</p>
                            </div>
                        </div>

                        <div class="card col-md-4 col-sm-12" style="background: none; border: none; float: left;">
                            <div class="cart-body col-md-10" style="text-align: center;">
                                <h1 style="color: #ffae4c; "><img class="mt-4" src="<?php echo e(asset('project_website/assets/images/logo/mobile.png')); ?>" style="height: 68px; width: 68px;"></h1>
                                <h3 style="color: #FFFFFF; font-family: Helvetica Neue, Helvetica, sans-serif !important; ">Simple to use<strong></strong></h3>
                                <p style="color: #FFFFFF;">Easy to use ordering system makes ordering for your whole team a breeze.</p>
                            </div>
                        </div>

                    </div>

            </div>
        </section>


    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('project_website.website_layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projects\catering\resources\views/project_website/website_pages/landing.blade.php ENDPATH**/ ?>