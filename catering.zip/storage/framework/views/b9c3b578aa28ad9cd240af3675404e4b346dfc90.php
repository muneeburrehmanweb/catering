<?php $__env->startSection('title'); ?>
    Services
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('page_title'); ?>
    Services
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
    Services
<?php $__env->stopSection(); ?>
<div class="row">
    <!-- customar project  start -->
    <div class="col-xl-12">
        <div class="card">
            <div class="card-body">
                <div class="row align-items-center m-l-0">
                    <div class="col-sm-6">
                        <h5>My Services</h5>
                    </div>
                    <div class="col-sm-6 text-right">
                        <a href="<?php echo e(route('add_services')); ?>" class="btn btn-success btn-sm btn-round has-ripple" ><i class="feather icon-plus"></i> Service</a>
                    </div>
                </div>
                <hr>
                <div class="table-responsive">
                    <table id="report-table" class="table mb-0">
                        <thead class="thead-light">
                        <tr>
                            <th>Product</th>
                            <th>Category</th>
                            <th>Added Date</th>
                            <th>Price</th>

                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $show_services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keys=>$values): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="align-middle">

                                <img src="<?php echo e(asset('project_panel/assets/images/service_images/'.App\Models\ServiceImage::Where('service_id',$values->id)->pluck('image')->first())); ?>" alt="contact-img" title="contact-img" class="rounded mr-3" height="48" />
                                <p class="m-0 d-inline-block align-middle font-16">
                                    <a href="#!" class="text-body"><?php echo e($values->title ?? ''); ?></a>






                                </p>
                            </td>
                            <td class="align-middle">
                                <?php echo e($values->category ?? ''); ?>

                            </td>
                            <td class="align-middle">
                                <?php echo e($values->created_at ?? ''); ?>

                            </td>
                            <td class="align-middle">
                                $<?php echo e($values->price ?? ''); ?>

                            </td>



                            <td class="align-middle">
                                <span class="badge badge-success">Active</span>
                            </td>

                            <td class="table-action">
                                <a href="#!" class="btn btn-icon btn-outline-primary"><i class="feather icon-eye"></i></a>
                                <a href="<?php echo e(route('edit_services',$values->id)); ?>" class="btn btn-icon btn-outline-success"><i class="feather icon-edit"></i></a>
                                <a href="<?php echo e(route('del_services',$values->id)); ?>" class="btn btn-icon btn-outline-danger"><i class="feather icon-trash-2"></i></a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <!-- customar project  end -->
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('project_panel.panel_layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projects\catering\resources\views/project_panel/panel_pages/services.blade.php ENDPATH**/ ?>