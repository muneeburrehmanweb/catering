
<?php $__env->startSection('title'); ?>
    Dashboard
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


    <?php $__env->startSection('page_title'); ?>
        Dashboard
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('breadcrumb'); ?>
        Dashboard
    <?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('project_panel.panel_layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projects\catering\resources\views/project_panel/panel_pages/dashboard.blade.php ENDPATH**/ ?>