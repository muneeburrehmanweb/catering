
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Catering</title>
    <link rel="shortcut icon" href="<?php echo e(asset('project_website/assets/images/logo/favourite_icon.png')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('project_website/assets/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('project_website/assets/css/fontawesome.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('project_website/assets/css/aos.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('project_website/assets/css/animate.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('project_website/assets/css/slick.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('project_website/assets/css/slick-theme.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('project_website/assets/css/magnific-popup.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('project_website/assets/css/nice-select.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('project_website/assets/css/jquery-ui.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('project_website/assets/css/style.css')); ?>">
</head>
<?php /**PATH C:\projects\catering\resources\views/project_website/website_assets/head.blade.php ENDPATH**/ ?>