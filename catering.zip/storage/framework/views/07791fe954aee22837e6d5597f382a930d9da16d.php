<!DOCTYPE html>
<html lang="en">

<?php echo $__env->make('project_panel.panel_assets.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>
    <!-- [ Main Content ] start -->
    <?php $__env->startSection('content'); ?>
    <?php echo $__env->yieldSection(); ?>
    <!-- [ Main Content ] start -->

    <!-- Required Js -->
    <?php echo $__env->make('project_panel.panel_assets.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html><?php /**PATH C:\projects\catering\resources\views/project_panel/panel_layouts/auth.blade.php ENDPATH**/ ?>