<!DOCTYPE html>
<html lang="en">
<!-- Mirrored from html.merku.love/rotors/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 22 May 2021 09:13:29 GMT -->
<?php echo $__env->make('project_website.website_assets.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body data-bg-image="demo_assets/images/backgrounds/bg_00.png">
<div id="thetop"></div>
<div class="backtotop"><a href="#" class="scroll"><i class="far fa-arrow-up"></i></a></div>

<?php echo $__env->make('project_website.website_assets.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('content'); ?>


<?php echo $__env->make('project_website.website_assets.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('project_website.website_assets.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
<!-- Mirrored from html.merku.love/rotors/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 22 May 2021 09:14:00 GMT -->
</html>
<?php /**PATH C:\projects\catering\resources\views/project_website/website_layouts/master.blade.php ENDPATH**/ ?>